100% Free Font

Introducing So Cheerful: 
A script typeface with a casual feel.

With its modern and minimal look, So Cheerful font brings a laid-back and clean style to websites, modern logos, branding identity, social media quotes, wedding stationery, and whatever you can think up!

So Cheerful script features uppercase, lowercase, and numbers for a custom casual look.
Thanks for stopping by, and please get in touch if you have any questions! 
-Jason

https://www.behance.net/jasonguillard

